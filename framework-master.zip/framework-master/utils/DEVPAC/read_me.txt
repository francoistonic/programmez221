Install the folder "DEVPAC" on C:\
Launch "DEVPAC.PRG"
-> DevPacST version 2.25fr