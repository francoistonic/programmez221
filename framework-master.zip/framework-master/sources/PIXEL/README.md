# Programmez! n°2xx
Article : Le graphisme sur ATARI ST<br>
ATARI STF/E ASM-68k dots displayed Examples